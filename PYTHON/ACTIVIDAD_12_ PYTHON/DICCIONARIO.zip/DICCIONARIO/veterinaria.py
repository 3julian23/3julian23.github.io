#Diccionario de veterinaria

vete={"Sargento":{"Nombre":"Sargento","Raza":"Husky","Genero":"M","Dueño":"Isaac","Telefono":389237652,"Color":"Negro","Vacunas":"Si"},"Pirula":{"Nombre":"Pirula","Raza":"Labrador","Genero":"H","Dueño":"Mayerlis","Telefono":3938476541,"Color":"Blanco","Vacunas":3},"Zeus":{"Nombre":"Zeus","Raza":"Dalmata","Genero":"M","Dueño":"Jorge","Telefono":3182736543,"Color":"Blanco y Negro","Vacunas":4},"Tobby":{"Nombre":"Tobby","Raza":"Pastor Belga","Genero":"M","Dueño":"Paula","Telefono":3098765432,"Color":"Cafe","Vacunas":"si"},"Lila":{"Nombre":"Lila","Raza":"Pitbull","Genero":"H","Dueño":"Said","Telefono":3028641224,"Color":"Gris","Vacunas":"si"}}
print(vete["Sargento"])
print(vete["Pirula"])
print(vete["Zeus"])
print(vete["Tobby"])
print(vete["Lila"])