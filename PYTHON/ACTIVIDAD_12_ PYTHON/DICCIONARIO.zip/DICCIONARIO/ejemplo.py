#Diccionario:Busqueda por clave
dict={"sucre":"sincelejo","Cordoba":"Monteria","Bolivar":"Cartagena","Atlantico":"Barranquilla","Antioquia":"Medellin","Nariño":"Pasto","Boyaca":"Tunja","Caldas":"Manizales","Choco":"Quibdo","Magdalena":"Santamarta"}
print(dict["sucre"])
print(dict["Cordoba"])
print(dict["Bolivar"])
print(dict["Atlantico"])
print(dict["Antioquia"])
print(dict["Nariño"])
print(dict["Boyaca"])
print(dict["Caldas"])
print(dict["Choco"])
print(dict["Magdalena"])


print("\n")
#escriba un diccionario de las marca de veiculos y los modelos. debe terner un tamaño minimo de 10 elementos
dict={"Chevrolet":"Chevrolet onix","Suzuki":"Suzuki swift","Kia":"Kia Picanto","Renault":"Renault logan","Mazda":"Mazda CX-30","Toyota":"Fortuner","Volkswagen":"Volkswagen T-cross","Lamborghini":"Murcielago","Ferrari":"Ferrari 296 GTB","Mustang":"Mustang GT500"}
print(dict["Chevrolet"])
print(dict["Suzuki"])
print(dict["Kia"])
print(dict["Renault"])
print(dict["Mazda"])
print(dict["Toyota"])
print(dict["Volkswagen"])
print(dict["Lamborghini"])
print(dict["Ferrari"])
print(dict["Mustang"])

print("\n")
#Diccionario de frutas 
frutas={"Dulces":["Mango","Piña","Sandia","Pera","Manzana"], "Citricas":["Naranja","Limon","Mandarina","lulo","lima"], "Secos":["Almendras","Avellanas","Castaña","Nueces de Macadamia"], "Neutras":["Aguacate","Aceitunas","Cacahuate","Mani","Corozo"]}
print(frutas["Dulces"])
print(frutas["Citricas"])
print(frutas["Secos"])
print(frutas["Neutras"])

print("\n")
#Diccionario de Personas
personas={"John Perez":{"Id":110267845,"Edad":17,"Sexo":"M","Cel":300678,"Correo":"iogmail.com"},"Julian Vergara":{"Id":1102794338,"Sexo":"M","Cel":3043027,"Correo":"vergara@gmail.com"},"Viviana Tovar":{"Id":22868196,"Sexo":"F","Cel":3013152,"Correo":"tovar@gmail.com"},"Omar Romero":{"Id":3838787,"Sexo":"M","Cel":3015595,"Correo":"Romero@gmail.com"},"Mayerlis Cardenas":{"Id":1103106637,"Sexo":"F","Cel":3042730,"Correo":"vergara@gmail.com"}}
print(personas["John Perez"])
print(personas["Julian Vergara"])
print(personas["Viviana Tovar"])
print(personas["Omar Romero"])
print(personas["Mayerlis Cardenas"])