#convertir 

#funcion convertir de horas a minutos
def convertir():
    minutos=hora*60
    print("El tiempo a convertir fue: ",minutos ,"minutos")

#aplicacion para convertir el tiempo de hora a minutos
hora=int(input("Digite las horas a convertir: "))

convertir()#llamado de la funcion convetir 
