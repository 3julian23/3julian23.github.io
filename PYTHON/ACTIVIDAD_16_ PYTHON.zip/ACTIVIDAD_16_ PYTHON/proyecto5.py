#diseñe una app que calcule el area del rectangulo y luego sea llamada por el algoritmo 
#funcion rectangulo
def rectangulo():
    area=b*a
    print("El area del rectangulo es: ", area)

#app que calcula el area del rectangulo 
b=int(input("digite la base del rectangulo: "))
a=int(input("Digite la altura del triangulo: "))


rectangulo()
