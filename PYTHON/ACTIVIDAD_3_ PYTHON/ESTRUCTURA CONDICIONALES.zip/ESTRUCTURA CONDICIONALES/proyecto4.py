#App que muestre si la nota es aprobada o reprobada

n=int(input("Ingrese la nota: "))

if n>3:
    print("Su nota ", n,  "es aprobada")

else:
    print("Su nota ", n,  "es reprobada")