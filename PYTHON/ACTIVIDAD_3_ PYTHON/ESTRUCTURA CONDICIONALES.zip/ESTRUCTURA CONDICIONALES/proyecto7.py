#App que muestre si tenemos ganancias o perdidas

n=int(input("Digite su valor de ingreso: "))

a=int(input("Digite su valor de ganancias: "))

if n>a:
    print("La ganancia ", n , "no hay perdida")

else:
    print("La ganancia ", n , " hay perdida")
