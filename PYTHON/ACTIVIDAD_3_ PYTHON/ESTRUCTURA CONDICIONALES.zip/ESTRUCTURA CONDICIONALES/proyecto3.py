#App que muestre si el numero es mayor a 10 o menor a 10 

n=int(input("Digite numero: "))

if n>10:
    print("El numero ", n , "es mayor que 10")

else:
     print("El numero ", n , "es menor que 10") 