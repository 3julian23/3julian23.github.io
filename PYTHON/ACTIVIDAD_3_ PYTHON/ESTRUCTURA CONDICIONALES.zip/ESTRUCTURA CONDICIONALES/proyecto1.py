#App que al ingresar un numero diga si es positivo o negativo
n=int(input("Digite el numero: "))

if n>0:
    print("El numero ", n , "es positivo ")

else: 
    print("El numero ", n , "es negativo ")