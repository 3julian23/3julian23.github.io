#App que muestre si es mayor de edad 

e=int(input("Ingrese su edad: "))

if e>18:
    print("Su edad es ", e , "ya es una persona mayor de edad")

else:
   print("Su edad es ", e , "no es una persona mayor de edad")
