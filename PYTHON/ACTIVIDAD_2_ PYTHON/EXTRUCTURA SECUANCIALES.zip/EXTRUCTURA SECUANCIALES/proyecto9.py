#Algoritmo que calcule 2 numeros enteros
from __future__ import division


a=int(input("Digite el 1er numero: "))
b=int(input("Digite el 2do numero: "))

suma=a+b
resta=a-b
multi=a*b
division=a/b

print("El resultado de la suma es: ",suma)
print("El resultado de la resta es: ",resta)
print("El resultado de la multiplicacion es: ",multi)
print("El resultado de la division es: ",division)
