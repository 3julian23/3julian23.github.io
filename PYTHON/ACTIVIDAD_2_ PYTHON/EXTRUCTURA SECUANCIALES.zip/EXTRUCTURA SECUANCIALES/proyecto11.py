#Algoritmo que calcule los minutos a hora
a=int(input("Ingrese el valor en minutos: "))
h=a/60
print("La hora es: ",h)