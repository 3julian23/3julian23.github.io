#Algoritmo que calcule el prestamo bancario
a=int(input("Digite la cantidad el prestamo: "))
anual=0.27*a
mensual=anual/12
print("El total a pagar anualmente es: ",anual)
print("El total a pagar mensualmente es: ",mensual)
