#Algoritmo que calcule el area de un circulo

a=int(input("Digite el radio del circulo:"))
print("El radio es: ",a)
pi=3.1416
b=pi*a*a
print("El radio del circulo es: ",b)
