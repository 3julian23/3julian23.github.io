#Algoritmo que convierte el dolar a peso

dolar=int(input("Digite el numero:"))
peso=4650
peso=dolar*4650
print("El dolar en peso colombiano esta: ",peso)