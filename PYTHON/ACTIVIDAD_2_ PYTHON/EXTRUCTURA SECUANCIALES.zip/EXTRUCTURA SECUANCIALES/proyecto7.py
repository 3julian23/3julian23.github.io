#Algoritmo que defina el descuento y total

salario=3000000
descuento=salario*0.05
print("El descuento de su salario es: ",descuento)
monto=salario-150000
print("El monto total de su salario es: ",monto)