"""
Creado por. Julian vergara
Algoritmo que al ingresar dos numeros los sume
"""
a=int(input("Digite el primer numero: "))
b=int(input("Digite el segundo numero: "))
c=a+b
print("La suma de: ",a, "+",b, "es:" ,c)