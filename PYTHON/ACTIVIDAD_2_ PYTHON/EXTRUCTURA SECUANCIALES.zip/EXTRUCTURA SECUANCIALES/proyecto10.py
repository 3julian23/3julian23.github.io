#Algoritmo que muestra el promedio de 3 notas

a=int(input("Digite el 1er numero: "))
b=int(input("Digite el 2do numero: "))
c=int(input("Digite el 3er numero: "))

promedio=(a+b+c)/3
print("El promedio es: ",promedio)