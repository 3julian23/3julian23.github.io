#ciclo para : App que muestra los numeros del 1 al 10 

for i in range(10,0,-1):
    print(i)