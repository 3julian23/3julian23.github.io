#while : App que me muestre los numeros de el 1 al 10 
i=1
while i<=10:
    print(i)
    i=i+1