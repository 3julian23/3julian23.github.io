#lista en blanco
titulo=[]
genero=[]
duracion=[]
protagonista=[]
año_de_estreno=[]
precio=[]
idioma=[]

tamaño=int(input("Tamaño de la lista ? : "))
#recorremos la lista hasta el tamaño definido
for i in range(tamaño):
    print("Ingrese los datos de las peliculas: ", i + 1)
    ti=input("titulo de las peliculas: ")
    gen=input("genero de las peliculas: ")
    dura=input("duracion de las peliculas: ")
    prota=input("protagonista de las pelicula: ")
    ae=input("año de estreno de la pelicula: ")
    pvp=input("precio de la entrada a la pelicula: ")
    idi=input("idioma de la pelicula: ")
    titulo.append(ti)
    genero.append(gen)
    duracion.append(dura)
    protagonista.append(prota)
    año_de_estreno.append(ae)
    precio.append(pvp)
    idioma.append(idi)
print("informacion sobre las peliculas: ")

for i in range(tamaño):
    print("================================")
    print("informacion sobre las peliculas")
    print("================================")
    print("____________________")
    print("titulo: ",titulo[i])
    print("genero: ",genero[i])
    print("duracion: ", duracion[i])
    print("protagonista: ", protagonista[i])
    print("año de estreno: ", año_de_estreno[i])
    print("precio: ", precio[i])
    print("idioma: ", idioma[i])
    print("____________________")
