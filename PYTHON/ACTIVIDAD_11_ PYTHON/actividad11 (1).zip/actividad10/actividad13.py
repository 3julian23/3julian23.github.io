#lista en blanco
codigo_factura=[]
codigo_cliente=[]
nombre_cliente=[]
fecha_factura=[]
descripcion_del_producto=[]
precio_unitario=[]
cantidad=[]
total=[]


tamaño=int(input("Tamaño de la lista ? : "))
#recorremos la lista hasta el tamaño definido
for i in range(tamaño):
    print("Ingrese los datos de facturacion: ", i + 1)
    cf=input("codigo de la factura: ")
    cc=input("codigo del cliente: ")
    nc=input("nombre del cliente: ")
    ff=input("fecha de la factura: ")
    dp=input("descripcion del producto: ")
    pu=int(input("precio por unidad: "))
    cant=int(input("cantidad de los productos: "))
    codigo_factura.append(cf)
    codigo_cliente.append(cc)
    nombre_cliente.append(nc)
    fecha_factura.append(ff)
    descripcion_del_producto.append(dp)
    precio_unitario.append(pu)
    cantidad.append(cant)
    total.append(cant*pu)


print("informacion sobre las facturas: ")

for i in range(tamaño):
    print("===================================================")
    print("          informacion sobre las facturas::  ")
    print("===================================================")
    print("____________________")
    print("codigo de la factura: ",codigo_factura[i])
    print("codigo del cliente: ",codigo_cliente[i])
    print("nombre del cliente: ", nombre_cliente[i])
    print("fecha de la factura: ", fecha_factura[i])
    print("descripcion del producto: ", descripcion_del_producto[i])
    print("precio por unidad: ", precio_unitario[i])
    print("cantidad de los productos: ", cantidad[i])
    print("total: ", total[i])
    print("____________________")
