#Lista en blanco
nombres=[]
identificacion=[]
correo=[]
telefono=[]
ciudad_donde_vive=[]
direccion=[]
fecha_de_nacimiento=[]
lugar_de_nacimiento=[]
#definimos tamaño para la lista
#se puede cambiar
tamaño=int(input("Tamaño de la lista ? : "))
#recorremos la lista hasta el tamaño definido
for i in range(tamaño):
    print("Ingrese los datos del aprendiz ", i + 1)
    nombre=input("nombre del aprendiz: ")
    id=input("N° de identificacion: ")
    co=input("Correo electronico: ")
    tel=input("telefono-celular: ")
    ciu=input("ciudad donde esta viviendo: ")
    dic=input("direccion de residencia: ")
    fec=input("fecha de nacimiento: ")
    lug=input("lugar de nacimiento: ")
    nombres.append(nombre)
    identificacion.append(id)
    correo.append(co)
    telefono.append(tel)
    ciudad_donde_vive.append(ciu)
    direccion.append(dic)
    fecha_de_nacimiento.append(fec)
    lugar_de_nacimiento.append(lug)
print("informacion del aprendiz: ")


for i in range(tamaño):
    print("__________________")
    print("nombres: ", nombres[i])
    print("identificacion: ", identificacion[i])
    print("correo: ",correo[i] )
    print("telefono: ",telefono[i])
    print("ciudad donde esta siendo residente: ",ciudad_donde_vive[i])
    print("direccion: ",direccion[i])
    print("fecha de nacimiento: ",fecha_de_nacimiento[i])
    print("lugar de nacimiento: ", lugar_de_nacimiento[i])
print("____________________")
