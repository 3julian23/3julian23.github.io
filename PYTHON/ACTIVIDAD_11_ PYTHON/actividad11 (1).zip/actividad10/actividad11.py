#lista en blanco
marca=[]
modelo=[]
color=[]
combustible=[]
cilindraje=[]
precio=[]

tamaño=int(input("Tamaño de la lista ? : "))
#recorremos la lista hasta el tamaño definido
for i in range(tamaño):
    print("Ingrese los datos del vehiculo: ", i + 1)
    mc=input("marca del vehiculo: ")
    mod=input("modelo del vehiculo: ")
    col=input("color del vehiculo: ")
    combus=input("combustible que usa el vehiculo: ")
    cilin=input("cilindraje del vehiculo: ")
    pvp=input("precio del vehiculo: ")
    marca.append(mc)
    modelo.append(mod)
    color.append(col)
    combustible.append(combus)
    cilindraje.append(cilin)
    precio.append(pvp)
print("informacion sobre el vehiculo: ")

for i in range(tamaño):
    print("____________________")
    print("marca: ",marca[i])
    print("modelo: ",modelo[i])
    print("color: ", color[i])
    print("combustible: ", combustible[i])
    print("cilindraje: ", cilindraje[i])
    print("precio: ", precio[i])
    print("____________________")
