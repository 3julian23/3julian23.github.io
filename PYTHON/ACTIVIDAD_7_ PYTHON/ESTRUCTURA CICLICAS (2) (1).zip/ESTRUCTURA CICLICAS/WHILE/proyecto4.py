#App que al ingresar el valor inicial 
# y el valor final muestre los datos 
x=int(input("Digite el valor inicial :"))
y=int(input("Digite el valor final: "))

for i in range(x,y,1):
    print(i)
    i+=1

else:
    print("Los valores no son correctos")