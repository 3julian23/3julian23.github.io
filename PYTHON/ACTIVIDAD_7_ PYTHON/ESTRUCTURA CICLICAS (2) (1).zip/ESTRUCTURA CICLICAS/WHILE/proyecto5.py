#App que muestre los numeros del 1 al 100

i=1
while i<=100:
    print(i)
    i+=1
