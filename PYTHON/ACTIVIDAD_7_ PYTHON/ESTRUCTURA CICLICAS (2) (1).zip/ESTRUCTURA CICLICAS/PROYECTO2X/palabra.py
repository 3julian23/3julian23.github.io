#App que pida una palabra al usuario 
# y la muestre 10 veces por pantalla 

p=input("Digite una palabra: ")

for i in p*10:
   print(i ,end="  ")
    

