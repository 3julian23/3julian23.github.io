#Lista en blanco
nombres=[]
#definimos tamaño para la lista
#se puede cambiar
tamaño=int(input("Tamaño de la lista ? : "))
#recorremos la lista hasta el tamaño definido
for i in range(tamaño):
    print("Ingrese los datos del aprendiz ", i + 1)
    nombre=input("nombre del aprendiz: ")
    nombres.append(nombre)
print("los aprendicez son: ")


for i in range(tamaño):
    print("__________________")
    print("nombres: ", nombres[i])
print("____________________")
